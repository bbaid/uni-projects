# Демонстрация на програма от лекциите?

# Simple script that sums the first 10 numbers
S = 0
for i in range (11):
    S = S + i
    print(S)